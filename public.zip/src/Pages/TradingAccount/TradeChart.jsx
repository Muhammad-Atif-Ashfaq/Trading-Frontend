import React, { useState,useEffect } from 'react'

const TradeChart = () => {
    

 
  return (
   <h1>
    TradeChart</h1>
  )
}

export default TradeChart