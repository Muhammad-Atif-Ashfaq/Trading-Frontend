export const PDataSaveBtnStyle = {
  width: '180px',
  height: '50px',
  marginTop: '50px',
  borderRadius: '8px',
  }

  export const AddnewStyle = { 
  borderRadius: '8px', 
  padding: '14px, 20px, 14px, 20px',
  height: '48px',
  width: '180px',

}

export const footerStyle = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'end',
}

export const submitStyle = {
  width: '180px',
  height: '56px',
  padding: '8px, 16px, 8px, 16px',
  radius: '4px',
  marginTop: '16px',

}

export const numberInputStyle ={
   
  "input::-webkit-outer-spin-button, input::-webkit-inner-spin-button": {
      WebkitAppearance: "none",
      margin: 0,
                    
  }
}