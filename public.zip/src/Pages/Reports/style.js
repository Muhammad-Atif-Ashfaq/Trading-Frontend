export const FilterBtnStyle = { height: '48px', borderRadius: '8px' }
export const ChartStyle = { height: '400px', maxWidth: '100%' }